//
//  ScmRealityDebugView.swift
//  Quick3D
//
//  DEV-ONLY: render file .scm bằng RealityKit (ARView chế độ .nonAR) qua
//  SCMReader.parseModel + SCMRealityBuilder — để so trực tiếp với bản web
//  (three.js/WKWebView) cùng một file.
//
//  ARView KHÔNG có allowsCameraControl như SCNView → tự làm orbit camera:
//  • 1 ngón kéo = xoay quanh model
//  • pinch      = zoom
//

import SwiftUI
import RealityKit
import UniformTypeIdentifiers

struct ScmRealityDebugView: View {
    @State private var rootEntity: Entity?
    @State private var status = "Bấm 📂 để chọn file .scm"
    @State private var showPicker = false

    var body: some View {
        ZStack(alignment: .top) {
            ScmRealityView(rootEntity: rootEntity)
                .ignoresSafeArea()

            HStack(spacing: 8) {
                Button("📂 Mở .scm") { showPicker = true }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color(red: 0.18, green: 0.44, blue: 0.70))
                    .foregroundColor(.white)
                    .cornerRadius(7)

                Text(status)
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(.white)
                    .padding(6)
                    .background(Color.black.opacity(0.55))
                    .cornerRadius(6)

                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.top, 8)
        }
        .fileImporter(
            isPresented: $showPicker,
            allowedContentTypes: [UTType.data, UTType.item]
        ) { result in
            switch result {
            case .success(let url): loadScm(url)
            case .failure(let err): status = "Lỗi chọn file: \(err.localizedDescription)"
            }
        }
    }

    private func loadScm(_ url: URL) {
        guard url.pathExtension.lowercased() == "scm" else {
            status = "\(url.lastPathComponent) không phải .scm"
            return
        }
        status = "Đang parse \(url.lastPathComponent)…"
        // File từ Files app nằm ngoài sandbox — phải xin quyền security-scoped.
        let secured = url.startAccessingSecurityScopedResource()
        defer { if secured { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try Data(contentsOf: url)
            let t0 = CFAbsoluteTimeGetCurrent()
            let model = try SCMReader.parseModel(data)
            let entity = try SCMRealityBuilder.build(model)
            let ms = Int((CFAbsoluteTimeGetCurrent() - t0) * 1000)
            rootEntity = entity
            status = "\(url.lastPathComponent) — parse+build \(ms) ms (RealityKit)"
        } catch {
            status = "❌ \(error.localizedDescription)"
        }
    }
}

// ARView bọc cho SwiftUI. Mỗi lần rootEntity đổi: xoá model cũ, add model mới,
// đặt orbit camera nhìn trọn bounding sphere của model.
struct ScmRealityView: UIViewRepresentable {
    let rootEntity: Entity?

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> ARView {
        let view = ARView(frame: .zero, cameraMode: .nonAR, automaticallyConfigureSession: false)
        view.environment.background = .color(UIColor(white: 0.12, alpha: 1))

        let anchor = AnchorEntity(world: .zero)
        anchor.name = "scm-anchor"
        view.scene.addAnchor(anchor)

        // Bộ đèn mô phỏng viewer web (3 DirectionalLight). RealityKit không có
        // ambient light → bù bằng cường độ directional (lux).
        func addDirectional(_ x: Float, _ y: Float, _ z: Float, _ lux: Float) {
            let light = DirectionalLight()
            light.light.intensity = lux
            light.look(at: .zero, from: SIMD3(x, y, z), relativeTo: nil)
            anchor.addChild(light)
        }
        addDirectional(1, 2, 3, 3000)
        addDirectional(-1, -1, -1, 2000)
        addDirectional(0, 0, 1, 1500)

        let camera = PerspectiveCamera()
        camera.name = "scm-camera"
        anchor.addChild(camera)
        context.coordinator.camera = camera

        // Orbit controls
        let pan = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.onPan(_:)))
        pan.maximumNumberOfTouches = 1
        view.addGestureRecognizer(pan)
        let pinch = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.onPinch(_:)))
        view.addGestureRecognizer(pinch)

        return view
    }

    func updateUIView(_ view: ARView, context: Context) {
        // entity.parent != nil nghĩa là model này đã add rồi (SwiftUI gọi update
        // nhiều lần) — chỉ dựng lại khi có entity MỚI.
        guard let entity = rootEntity, entity.parent == nil,
              let anchor = view.scene.anchors.first(where: { $0.name == "scm-anchor" }) as? AnchorEntity
        else { return }

        // Chỉ dọn model cũ — KHÔNG đụng đèn/camera.
        anchor.children.filter { $0.name == "scm-model" }.forEach { $0.removeFromParent() }

        let container = Entity()
        container.name = "scm-model"
        container.addChild(entity)
        anchor.addChild(container)

        // Fit camera theo bounding sphere
        let bounds = entity.visualBounds(relativeTo: nil)
        let radius = max(bounds.boundingRadius, 0.5)
        if let cam = context.coordinator.camera {
            cam.camera.near = radius / 100
            cam.camera.far = radius * 20 + 1000
        }
        context.coordinator.target = bounds.center
        context.coordinator.distance = radius * 2.2
        context.coordinator.yaw = 0
        context.coordinator.pitch = 0
        context.coordinator.updateCamera()
    }

    // Orbit camera quanh target: yaw/pitch + distance (toạ độ cầu)
    final class Coordinator: NSObject {
        var camera: PerspectiveCamera?
        var target: SIMD3<Float> = .zero
        var distance: Float = 5
        var yaw: Float = 0
        var pitch: Float = 0
        private var lastPan: CGPoint = .zero
        private var pinchStartDistance: Float = 5

        @objc func onPan(_ g: UIPanGestureRecognizer) {
            if g.state == .began { lastPan = .zero }
            let t = g.translation(in: g.view)
            let dx = Float(t.x - lastPan.x)
            let dy = Float(t.y - lastPan.y)
            lastPan = t
            yaw -= dx * 0.01
            pitch = min(max(pitch - dy * 0.01, -.pi / 2 + 0.01), .pi / 2 - 0.01)
            updateCamera()
        }

        @objc func onPinch(_ g: UIPinchGestureRecognizer) {
            if g.state == .began { pinchStartDistance = distance }
            guard g.scale > 0 else { return }
            distance = min(max(pinchStartDistance / Float(g.scale), 0.05), 1_000_000)
            updateCamera()
        }

        func updateCamera() {
            guard let cam = camera else { return }
            let offset = SIMD3<Float>(
                cos(pitch) * sin(yaw),
                sin(pitch),
                cos(pitch) * cos(yaw)
            ) * distance
            let position = target + offset
            cam.look(at: target, from: position, relativeTo: nil)
        }
    }
}
