//
//  SCMRealityBuilder.swift
//  Quick3D
//
//  Dựng Entity RealityKit từ SCMModel (parse bởi SCMReader.parseModel).
//
//  Khác biệt so với viewer web three.js (giới hạn API RealityKit trên iOS 15):
//  • Vertex color: MeshDescriptor không có kênh color → BỎ QUA (có log số mesh bị bỏ).
//  • Double-sided: chưa có faceCulling trước iOS 18 → nhân đôi tam giác đảo winding
//    (index buffer x2 để khớp DoubleSide của web).
//  • Lambert: không có lighting model lambert → PBR roughness=1, metallic=0 (gần nhất).
//

import Foundation
import RealityKit
import UIKit
import simd

enum SCMRealityBuilder {

    /// UV của SCM đang khớp three.js (gốc TRÊN-trái); RealityKit/USD dùng
    /// gốc DƯỚI-trái → mặc định lật V. Nếu texture render bị ngược dọc thì tắt cờ này.
    static var flipUV = true

    static func build(_ model: SCMModel) throws -> Entity {
        let root = Entity()
        root.name = "SCM_Root"

        // Cache texture theo texId — nhiều material dùng chung 1 texture
        var texCache: [Int: TextureResource?] = [:]
        func textureResource(_ texId: Int) -> TextureResource? {
            if let cached = texCache[texId] { return cached }
            var res: TextureResource? = nil
            if texId >= 0 && texId < model.texImages.count, let cg = model.texImages[texId]?.cgImage {
                res = try? TextureResource.generate(from: cg, options: .init(semantic: .color))
                if res == nil {
                    print("[SCMRealityBuilder] ⚠️ tex[\(texId)] generate TextureResource FAIL")
                }
            }
            texCache[texId] = res
            return res
        }

        // Cache mesh theo meshId — nhiều entity SCM trỏ chung 1 geometry
        var meshCache: [Int: MeshResource?] = [:]
        var skippedVertexColorMeshes = 0
        func meshResource(_ meshId: Int) -> MeshResource? {
            if let cached = meshCache[meshId] { return cached }
            var res: MeshResource? = nil
            if meshId >= 0 && meshId < model.geometries.count {
                let geom = model.geometries[meshId]
                if geom.vertexColorOffset >= 0 { skippedVertexColorMeshes += 1 }
                if let g = extractGeometry(geom, model: model) {
                    var desc = MeshDescriptor(name: "scm_mesh_\(meshId)")
                    desc.positions = MeshBuffer(g.positions)
                    if let normals = g.normals { desc.normals = MeshBuffer(normals) }
                    if let uvs = g.uvs { desc.textureCoordinates = MeshBuffer(uvs) }
                    desc.primitives = .triangles(g.indices)
                    do {
                        res = try MeshResource.generate(from: [desc])
                    } catch {
                        print("[SCMRealityBuilder] ⚠️ mesh[\(meshId)] generate FAIL: \(error)")
                    }
                }
            }
            meshCache[meshId] = res
            return res
        }

        var appliedTextures = 0
        var skippedTextures = 0
        var entities = [Entity?](repeating: nil, count: model.entityCount)

        for i in 0..<model.entityCount {
            let meshId = Int(model.meshIds[i])
            let entity: Entity

            if let mesh = meshResource(meshId) {
                var mat = PhysicallyBasedMaterial()
                // Gần lambert nhất: nhám hoàn toàn, không kim loại
                mat.roughness = .init(floatLiteral: 1.0)
                mat.metallic = .init(floatLiteral: 0.0)

                // Default trắng — như web (màu thật đến từ texture/entity color)
                var tint = UIColor.white

                // Entity color
                if !model.entityColors.isEmpty && i < model.entityColors.count {
                    let c = model.entityColors[i]
                    if c.w > 0 {
                        tint = UIColor(
                            red: CGFloat(c.x) / 255.0,
                            green: CGFloat(c.y) / 255.0,
                            blue: CGFloat(c.z) / 255.0,
                            alpha: CGFloat(c.w) / 255.0
                        )
                    }
                }

                var texture: PhysicallyBasedMaterial.Texture? = nil
                let matId = Int(model.materialIds[i])
                if matId >= 0 && matId < model.materials.count {
                    let scmMat = model.materials[matId]
                    if scmMat.opacity < 255 {
                        mat.blending = .transparent(opacity: .init(floatLiteral: Float(scmMat.opacity) / 255.0))
                    }
                    // Texture: cùng điều kiện với viewer web — texId hợp lệ + geometry có UV
                    let texId = Int(scmMat.textureId)
                    let hasUV = meshId >= 0 && meshId < model.geometries.count && model.geometries[meshId].uvOffset >= 0
                    if texId >= 0, hasUV, let res = textureResource(texId) {
                        texture = .init(res)
                        tint = .white // texture đè màu — cùng thứ tự ưu tiên với viewer web
                        appliedTextures += 1
                    } else if texId >= 0 {
                        skippedTextures += 1
                    }
                }
                mat.baseColor = .init(tint: tint, texture: texture)

                entity = ModelEntity(mesh: mesh, materials: [mat])
            } else {
                entity = Entity() // group node không có geometry
            }

            entity.name = model.names[i]
            let q = model.rotations[i]
            entity.transform = Transform(
                scale: model.scales[i],
                rotation: simd_quatf(ix: q.x, iy: q.y, iz: q.z, r: q.w),
                translation: model.positions[i]
            )
            entities[i] = entity
        }

        // Build hierarchy
        for i in 0..<model.entityCount {
            guard let entity = entities[i] else { continue }
            let parentId = Int(model.parentIds[i])
            if parentId >= 0 && parentId < model.entityCount, let parent = entities[parentId] {
                parent.addChild(entity)
            } else {
                root.addChild(entity)
            }
        }

        // Z-up → Y-up: rotate +90° quanh X (cùng phép quay với viewer web)
        if model.coordSystem == 1 {
            root.orientation = simd_quatf(angle: .pi / 2, axis: SIMD3<Float>(1, 0, 0))
        }

        print("[SCMRealityBuilder] textures applied: \(appliedTextures), skipped: \(skippedTextures)")
        if skippedVertexColorMeshes > 0 {
            print("[SCMRealityBuilder] ⚠️ \(skippedVertexColorMeshes) mesh có vertex color bị BỎ QUA (RealityKit iOS 15 không hỗ trợ)")
        }

        return root
    }

    // MARK: - Extract geometry arrays

    private struct GeometryArrays {
        let positions: [SIMD3<Float>]
        let normals: [SIMD3<Float>]?
        let uvs: [SIMD2<Float>]?
        let indices: [UInt32]
    }

    // Đọc geometry stream từ SCMModel ra mảng thuần cho MeshDescriptor.
    // Offset normal/UV là BYTE offset, -1 = không có (khớp scm-load-worker.js bên web).
    private static func extractGeometry(_ geom: SCMGeometry, model: SCMModel) -> GeometryArrays? {
        guard let posBlock = model.posBlock, let indexBlock = model.indexBlock else { return nil }
        guard geom.vertexCount > 0 && geom.indexCount > 0 else { return nil }

        let data = model.data
        let vCount = Int(geom.vertexCount)
        let iCount = Int(geom.indexCount)
        let r = BinaryReader(data)

        // Positions (float32x3)
        let posStart = Int(posBlock.offset) + Int(geom.vertexOffset)
        guard posStart >= 0, posStart + vCount * 12 <= data.count else { return nil }
        r.seek(posStart)
        var positions = [SIMD3<Float>]()
        positions.reserveCapacity(vCount)
        for _ in 0..<vCount {
            positions.append(SIMD3(r.readFloat32(), r.readFloat32(), r.readFloat32()))
        }

        // Normals (float32x3, BYTE offset, -1 = không có)
        var normals: [SIMD3<Float>]? = nil
        if let normBlock = model.normBlock, geom.normalOffset >= 0 {
            let nStart = Int(normBlock.offset) + Int(geom.normalOffset)
            if nStart + vCount * 12 <= data.count {
                r.seek(nStart)
                var arr = [SIMD3<Float>]()
                arr.reserveCapacity(vCount)
                for _ in 0..<vCount {
                    arr.append(SIMD3(r.readFloat32(), r.readFloat32(), r.readFloat32()))
                }
                normals = arr
            }
        }

        // UVs (float32x2, BYTE offset, -1 = không có)
        var uvs: [SIMD2<Float>]? = nil
        if let uvBlock = model.uvBlock, geom.uvOffset >= 0 {
            let uvStart = Int(uvBlock.offset) + Int(geom.uvOffset)
            if uvStart + vCount * 8 <= data.count {
                r.seek(uvStart)
                var arr = [SIMD2<Float>]()
                arr.reserveCapacity(vCount)
                for _ in 0..<vCount {
                    let u = r.readFloat32()
                    let v = r.readFloat32()
                    arr.append(SIMD2(u, flipUV ? 1.0 - v : v))
                }
                uvs = arr
            }
        }

        // Indices (uint32)
        let idxStart = Int(indexBlock.offset) + Int(geom.indexOffset)
        guard idxStart + iCount * 4 <= data.count else { return nil }
        r.seek(idxStart)
        var indices = [UInt32]()
        indices.reserveCapacity(iCount * 2)
        for _ in 0..<iCount {
            indices.append(r.readUInt32())
        }

        // Double-sided: RealityKit trước iOS 18 không tắt được backface culling
        // → thêm bản sao mỗi tam giác với winding đảo (a,c,b).
        let triEnd = (iCount / 3) * 3
        var j = 0
        while j < triEnd {
            indices.append(indices[j])
            indices.append(indices[j + 2])
            indices.append(indices[j + 1])
            j += 3
        }

        return GeometryArrays(positions: positions, normals: normals, uvs: uvs, indices: indices)
    }
}
