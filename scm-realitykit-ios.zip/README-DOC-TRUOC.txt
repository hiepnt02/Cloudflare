﻿SCM RealityKit - cac file thay doi (nhanh feature/scm-v1)
=========================================================
Giai nen de len goc repo (giu nguyen cau truc thu muc).

LUU Y: zip KHONG the xoa giup ban file cu. Phai TU XOA file sau
khoi repo (da go khoi Xcode project trong pbxproj roi):
  ios/Quick3DProj/Quick3D/Camera/Reader/ScmNativeDebugView.swift

Noi dung:
- SCMReader.swift          : parse SCM -> SCMModel (khong con SceneKit)
- SCMRealityBuilder.swift  : MOI - dung Entity RealityKit tu SCMModel
- ScmRealityDebugView.swift: MOI - view debug RealityKit (orbit camera)
- ARProjectHepler.swift    : protocol doi SCNNode -> Entity, bo createNode point cloud
- LayerNode.swift          : model cay layer
- Quick3DApp.swift         : toggle debug Web / RealityKit
- project.pbxproj          : dang ky file moi, go ScmNativeDebugView

Cach test: scmDebugMode = true trong Quick3DApp.swift -> tab RealityKit -> mo file .scm
Neu texture bi nguoc doc: doi SCMRealityBuilder.flipUV = false
