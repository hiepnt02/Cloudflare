//
//  SCMReader.swift
//  Quick3D
//
//  SCM binary format reader — parse nhị phân + dựng Entity RealityKit
//  (phần dựng nằm ở SCMRealityBuilder)
//

import Foundation
import simd
import RealityKit
import UIKit
import Alamofire

// MARK: - SCM Types

private let SCM_HEADER_SIZE = 32
private let SCM_BLOCK_ENTRY_SIZE = 18
private let SCM_GEOMETRY_DESC_SIZE = 52
private let SCM_MATERIAL_DESC_SIZE = 16

private enum SCMBlockType: UInt16 {
    case parent         = 0x0001
    case meshId         = 0x0002
    case materialId     = 0x0003
    case color          = 0x0004
    case position       = 0x0005
    case rotation       = 0x0006
    case scale          = 0x0007
    case category       = 0x0008
    case flags          = 0x0009
    case name           = 0x000A
    case geometryTable  = 0x0100
    case materialTable  = 0x0101
    case textureTable   = 0x0102
    case positionsStream = 0x0200
    case normalsStream  = 0x0201
    case uvsStream      = 0x0202
    case indicesStream  = 0x0203
    case vertexColorsStream = 0x0204
    case textureDataPool = 0x0205
    case stringTable    = 0x0206
}

private struct SCMHeader {
    let version: UInt16
    let entityCount: UInt32
    let blockCount: UInt16
    let geometryCount: UInt32
    let materialCount: UInt32
    let textureCount: UInt32
    let coordSystem: UInt8 // 0=Y-up, 1=Z-up
}

struct SCMBlockEntry {
    let blockType: UInt16
    let dataType: UInt8
    let encoding: UInt8
    let compression: UInt8
    let elementSize: UInt8
    let offset: UInt32
    let compressedSize: UInt32
    let rawSize: UInt32
}

struct SCMGeometry {
    let vertexCount: UInt32
    let indexCount: UInt32
    let vertexOffset: UInt32
    let normalOffset: Int32
    let uvOffset: Int32
    let indexOffset: UInt32
    let vertexColorOffset: Int32
    let bboxMin: SIMD3<Float>
    let bboxMax: SIMD3<Float>
}

struct SCMMaterial {
    let textureId: Int32
    let opacity: UInt8
    let flags: UInt8
}

// MARK: - Parsed model (renderer-agnostic)

/// Kết quả parse SCM ở dạng trung gian, không phụ thuộc framework render —
/// SCMRealityBuilder dựng Entity RealityKit từ đây.
struct SCMModel {
    let coordSystem: UInt8 // 0=Y-up, 1=Z-up
    let entityCount: Int
    let parentIds: [Int32]
    let meshIds: [Int32]
    let materialIds: [Int32]
    let positions: [SIMD3<Float>]
    let rotations: [SIMD4<Float>] // quaternion xyzw
    let scales: [SIMD3<Float>]
    let names: [String]
    let entityColors: [SIMD4<UInt8>] // rỗng nếu file không có block color
    let geometries: [SCMGeometry]
    let materials: [SCMMaterial]
    let texImages: [UIImage?]
    let data: Data
    let posBlock: SCMBlockEntry?
    let normBlock: SCMBlockEntry?
    let indexBlock: SCMBlockEntry?
    let uvBlock: SCMBlockEntry?
    let vcBlock: SCMBlockEntry?
}

// MARK: - Binary Reader Helper

final class BinaryReader {
    let data: Data
    var pos: Int = 0

    init(_ data: Data) { self.data = data }

    func seek(_ offset: Int) { pos = offset }

    func readUInt8() -> UInt8 {
        let v = data[data.startIndex + pos]
        pos += 1
        return v
    }

    func readUInt16() -> UInt16 {
        let v = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + 2))
            .withUnsafeBytes { $0.load(as: UInt16.self) }
        pos += 2
        return v
    }

    func readUInt32() -> UInt32 {
        let v = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + 4))
            .withUnsafeBytes { $0.load(as: UInt32.self) }
        pos += 4
        return v
    }

    func readInt32() -> Int32 {
        let v = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + 4))
            .withUnsafeBytes { $0.load(as: Int32.self) }
        pos += 4
        return v
    }

    func readFloat32() -> Float {
        let v = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + 4))
            .withUnsafeBytes { $0.load(as: Float.self) }
        pos += 4
        return v
    }

    func readInt8() -> Int8 {
        let v = Int8(bitPattern: data[data.startIndex + pos])
        pos += 1
        return v
    }

    func readBytes(_ count: Int) -> Data {
        let sub = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + count))
        pos += count
        return sub
    }
}

// MARK: - SCMReader

class SCMReader: ARProjectHepler {

    private let url: URL
    private var fileUrl: URL?
    var layers: [LayerNode] = []
    var node: Entity?

    override init(projectId: String) {
        self.url = URL(string: Constant.baseUrl + "api/v1/project/\(projectId)/ARdownload/SCM")!
        super.init(projectId: projectId)
    }

    override func update(min: SIMD3<Float>, max: SIMD3<Float>) {
        super.update(min: min, max: max)
        self.update(offset: self.center)
    }

    /// DEV: parse dữ liệu .scm local trực tiếp (không qua presign/server).
    /// Trả về root entity đã dựng — caller tự add vào scene và tự fit camera.
    func loadLocalData(_ data: Data) throws -> Entity {
        let scene = try SCMRealityBuilder.build(try Self.parseModel(data))
        layers = buildLayerTree(scene)
        return scene
    }

    func fetch() async {
        do {
            print("[SCMReader] Fetching presign URL from \(url)")
            let presignUrl = try await getPresignUrl(url)
            print("[SCMReader] Got presign URL, downloading...")
            self.fileUrl = try await downloadFile(presignUrl, fileName: "model.scm")
            print("[SCMReader] Downloaded to \(self.fileUrl?.path ?? "nil")")

            guard let fileUrl = self.fileUrl else {
                throw NSError(domain: "SCMReader", code: 1, userInfo: [NSLocalizedDescriptionKey: "No file downloaded"])
            }

            let data = try Data(contentsOf: fileUrl)
            print("[SCMReader] File size: \(data.count) bytes, parsing...")
            let scene = try SCMRealityBuilder.build(try Self.parseModel(data))
            print("[SCMReader] Parsed OK, \(scene.children.count) root children")

            let bounds = scene.visualBounds(relativeTo: nil)
            update(min: bounds.min, max: bounds.max)

            let rootEntity = Entity()
            self.node = rootEntity
            delegate?.onCreateNode(rootEntity)

            // Dời model về quanh gốc toạ độ (giữ nguyên phép quay Z-up ở root)
            scene.position -= self.center
            rootEntity.addChild(scene)

            // Build layer tree from entity names
            layers = buildLayerTree(scene)

            delegate?.onComplete()

        } catch {
            print("[SCMReader] ❌ ERROR: \(error)")
            setError(error)
        }
    }

    // MARK: - SCM Parser

    /// Parse phần nhị phân SCM thành model trung gian —
    /// SCMRealityBuilder.build(_:) dựng Entity RealityKit từ kết quả này.
    static func parseModel(_ data: Data) throws -> SCMModel {
        let reader = BinaryReader(data)

        // Validate magic
        let m0 = reader.readUInt8(), m1 = reader.readUInt8(), m2 = reader.readUInt8(), m3 = reader.readUInt8()
        guard (m0 == 0x53 && m1 == 0x43 && m2 == 0x4D && (m3 == 0x00 || m3 == 0x5A)) else {
            throw NSError(domain: "SCMReader", code: 2, userInfo: [NSLocalizedDescriptionKey: "Invalid SCM magic"])
        }

        // Header
        let header = SCMHeader(
            version: reader.readUInt16(),
            entityCount: reader.readUInt32(),
            blockCount: reader.readUInt16(),
            geometryCount: reader.readUInt32(),
            materialCount: reader.readUInt32(),
            textureCount: reader.readUInt32(),
            coordSystem: reader.readUInt8()
        )
        reader.seek(SCM_HEADER_SIZE) // skip reserved bytes

        // Block directory
        var blocks: [SCMBlockEntry] = []
        for _ in 0..<header.blockCount {
            blocks.append(SCMBlockEntry(
                blockType: reader.readUInt16(),
                dataType: reader.readUInt8(),
                encoding: reader.readUInt8(),
                compression: reader.readUInt8(),
                elementSize: reader.readUInt8(),
                offset: reader.readUInt32(),
                compressedSize: reader.readUInt32(),
                rawSize: reader.readUInt32()
            ))
        }

        let N = Int(header.entityCount)

        // Helper to find block
        func findBlock(_ type: SCMBlockType) -> SCMBlockEntry? {
            blocks.first { $0.blockType == type.rawValue }
        }

        // Read masked Int32 component
        func readMaskedInt32(_ type: SCMBlockType, defaultVal: Int32) -> [Int32] {
            guard let block = findBlock(type) else { return [Int32](repeating: defaultVal, count: N) }
            let r = BinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            var result = [Int32](repeating: defaultVal, count: N)
            for i in 0..<N {
                if mask[i] != 0 { result[i] = r.readInt32() }
            }
            return result
        }

        // Read masked Float32x3 component
        func readMaskedFloat3(_ type: SCMBlockType, defaultVal: SIMD3<Float>) -> [SIMD3<Float>] {
            guard let block = findBlock(type) else { return [SIMD3<Float>](repeating: defaultVal, count: N) }
            let r = BinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            var result = [SIMD3<Float>](repeating: defaultVal, count: N)
            for i in 0..<N {
                if mask[i] != 0 { result[i] = SIMD3(r.readFloat32(), r.readFloat32(), r.readFloat32()) }
            }
            return result
        }

        // Read masked Float32x4 component
        func readMaskedFloat4(_ type: SCMBlockType, defaultVal: SIMD4<Float>) -> [SIMD4<Float>] {
            guard let block = findBlock(type) else { return [SIMD4<Float>](repeating: defaultVal, count: N) }
            let r = BinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            var result = [SIMD4<Float>](repeating: defaultVal, count: N)
            for i in 0..<N {
                if mask[i] != 0 { result[i] = SIMD4(r.readFloat32(), r.readFloat32(), r.readFloat32(), r.readFloat32()) }
            }
            return result
        }

        // Read masked UInt32 component
        func readMaskedUInt32(_ type: SCMBlockType, defaultVal: UInt32) -> [UInt32] {
            guard let block = findBlock(type) else { return [UInt32](repeating: defaultVal, count: N) }
            let r = BinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            var result = [UInt32](repeating: defaultVal, count: N)
            for i in 0..<N {
                if mask[i] != 0 { result[i] = r.readUInt32() }
            }
            return result
        }

        // Read entity components
        let parentIds  = readMaskedInt32(.parent, defaultVal: -1)
        let meshIds    = readMaskedInt32(.meshId, defaultVal: -1)
        let materialIds = readMaskedInt32(.materialId, defaultVal: -1)
        let positions  = readMaskedFloat3(.position, defaultVal: .zero)
        let rotations  = readMaskedFloat4(.rotation, defaultVal: SIMD4(0, 0, 0, 1))
        let scales     = readMaskedFloat3(.scale, defaultVal: SIMD3(1, 1, 1))
        let nameRefs   = readMaskedUInt32(.name, defaultVal: 0)

        // Read string table
        var strings: [String] = [""]
        if let block = findBlock(.stringTable) {
            let r = BinaryReader(data)
            r.seek(Int(block.offset))
            let tableData = r.readBytes(Int(block.rawSize))
            var current = ""
            for byte in tableData {
                if byte == 0 {
                    strings.append(current)
                    current = ""
                } else {
                    current.append(Character(UnicodeScalar(byte)))
                }
            }
            if !current.isEmpty { strings.append(current) }
        }

        // Read geometry table
        var geometries: [SCMGeometry] = []
        if let block = findBlock(.geometryTable) {
            let r = BinaryReader(data)
            r.seek(Int(block.offset))
            for _ in 0..<header.geometryCount {
                geometries.append(SCMGeometry(
                    vertexCount: r.readUInt32(),
                    indexCount: r.readUInt32(),
                    vertexOffset: r.readUInt32(),
                    normalOffset: r.readInt32(),
                    uvOffset: r.readInt32(),
                    indexOffset: r.readUInt32(),
                    vertexColorOffset: r.readInt32(),
                    bboxMin: SIMD3(r.readFloat32(), r.readFloat32(), r.readFloat32()),
                    bboxMax: SIMD3(r.readFloat32(), r.readFloat32(), r.readFloat32())
                ))
            }
        }

        // Read material table
        var materials: [SCMMaterial] = []
        if let block = findBlock(.materialTable) {
            let r = BinaryReader(data)
            r.seek(Int(block.offset))
            for _ in 0..<header.materialCount {
                let texId = r.readInt32()
                _ = r.readUInt16() // textureScaleU (float16)
                _ = r.readUInt16() // textureScaleV (float16)
                let opacity = r.readUInt8()
                let flags = r.readUInt8()
                _ = r.readBytes(6) // reserved
                materials.append(SCMMaterial(textureId: texId, opacity: opacity, flags: flags))
            }
        }

        // Read texture table + decode images from textureDataPool.
        // Entry 24B: u16 w | u16 h | u8 compression | u32 dataOffset | u32 dataSize
        //            | 8B contentHash (+pad) — khớp parseTextures của scm-load-worker.js.
        // compression: 1=PNG, 2=JPEG, khác = RGBA8 thô.
        var texImages: [UIImage?] = []
        if let texBlock = findBlock(.textureTable), header.textureCount > 0 {
            let poolBlock = findBlock(.textureDataPool)
            let r = BinaryReader(data)
            for i in 0..<Int(header.textureCount) {
                r.seek(Int(texBlock.offset) + i * 24)
                let width = Int(r.readUInt16())
                let height = Int(r.readUInt16())
                let compression = r.readUInt8()
                _ = r.readUInt8() // 1B pad — dataOffset nằm ở byte 6 (worker đọc p+6)
                let dataOffset = Int(r.readUInt32())
                let dataSize = Int(r.readUInt32())
                // 8B contentHash: chỉ dùng dedup bên web — bỏ qua

                guard let pool = poolBlock, dataSize > 0 else { texImages.append(nil); continue }
                let start = Int(pool.offset) + dataOffset
                let end = Swift.min(start + dataSize, Int(pool.offset) + Int(pool.compressedSize))
                guard start < end, end <= data.count else { texImages.append(nil); continue }
                let bytes = data.subdata(in: start..<end)

                if compression == 1 || compression == 2 {
                    texImages.append(UIImage(data: bytes)) // PNG / JPEG
                } else {
                    texImages.append(Self.imageFromRGBA8(bytes, width: width, height: height))
                }
                if texImages[i] == nil {
                    print("[SCMReader] ⚠️ tex[\(i)] decode FAIL (comp=\(compression), \(dataSize)B, \(width)x\(height))")
                }
            }
            let ok = texImages.compactMap { $0 }.count
            print("[SCMReader] textures decoded: \(ok)/\(header.textureCount)")
        }

        // Read entity color (RGBA uint8x4)
        var entityColors: [SIMD4<UInt8>] = []
        if let block = findBlock(.color) {
            let r = BinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            entityColors = [SIMD4<UInt8>](repeating: SIMD4(0, 0, 0, 0), count: N)
            for i in 0..<N {
                if mask[i] != 0 {
                    let cr = r.readUInt8(), cg = r.readUInt8(), cb = r.readUInt8(), ca = r.readUInt8()
                    entityColors[i] = SIMD4(cr, cg, cb, ca)
                }
            }
        }

        // Resolve entity names (cùng logic với bản build node cũ)
        var names: [String] = []
        names.reserveCapacity(N)
        for i in 0..<N {
            let nameIdx = Int(nameRefs[i])
            names.append(nameIdx < strings.count ? strings[nameIdx] : "Entity_\(i)")
        }

        return SCMModel(
            coordSystem: header.coordSystem,
            entityCount: N,
            parentIds: parentIds,
            meshIds: meshIds,
            materialIds: materialIds,
            positions: positions,
            rotations: rotations,
            scales: scales,
            names: names,
            entityColors: entityColors,
            geometries: geometries,
            materials: materials,
            texImages: texImages,
            data: data,
            posBlock: findBlock(.positionsStream),
            normBlock: findBlock(.normalsStream),
            indexBlock: findBlock(.indicesStream),
            uvBlock: findBlock(.uvsStream),
            vcBlock: findBlock(.vertexColorsStream)
        )
    }

    // MARK: - Raw RGBA8 texture decode

    // Texture không nén (compression != 1/2) nằm trong pool dạng RGBA8 thô —
    // web dựng qua ImageData/OffscreenCanvas, bên này dựng CGImage tương đương.
    private static func imageFromRGBA8(_ bytes: Data, width: Int, height: Int) -> UIImage? {
        guard width > 0, height > 0, bytes.count >= width * height * 4 else { return nil }
        guard let provider = CGDataProvider(data: bytes as CFData) else { return nil }
        guard let cg = CGImage(
            width: width,
            height: height,
            bitsPerComponent: 8,
            bitsPerPixel: 32,
            bytesPerRow: width * 4,
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
            provider: provider,
            decode: nil,
            shouldInterpolate: true,
            intent: .defaultIntent
        ) else { return nil }
        return UIImage(cgImage: cg)
    }

    // MARK: - Octahedral Normal Decode

    private func octahedralDecode(_ ox: Int8, _ oy: Int8) -> SIMD3<Float> {
        var fx = Float(ox) / 127.0
        var fy = Float(oy) / 127.0
        let fz = 1.0 - (abs(fx) + abs(fy))

        if fz < 0 {
            let oldX = fx
            fx = (1.0 - abs(fy)) * (fx >= 0 ? 1.0 : -1.0)
            fy = (1.0 - abs(oldX)) * (fy >= 0 ? 1.0 : -1.0)
        }

        let len = sqrt(fx * fx + fy * fy + fz * fz)
        return SIMD3(fx, fy, fz) / len
    }

    // MARK: - Layer Tree

    private func buildLayerTree(_ rootEntity: Entity) -> [LayerNode] {
        func parse(_ entity: Entity, depth: Int) -> [LayerNode] {
            return entity.children.map { child in
                let id = child.name.isEmpty ? UUID().uuidString : child.name
                let name = child.name.isEmpty ? "Unnamed" : child.name
                let type = child.components.has(ModelComponent.self) ? "Geometry" : "Group"
                let childLayers = parse(child, depth: depth + 1)
                let layerNode = LayerNode(
                    id: id,
                    name: name,
                    displayName: nil,
                    type: type,
                    depth: depth,
                    children: childLayers,
                    isExpanded: true
                )
                childLayers.forEach { $0.parent = layerNode }
                return layerNode
            }
        }
        return parse(rootEntity, depth: 0)
    }
}
