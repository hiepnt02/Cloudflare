# SCM RealityKit Debug Viewer

Viewer debug render file `.scm` bằng RealityKit (native iOS).

## Cách build (Xcode trên Mac, ~2 phút)

1. Xcode → **File → New → Project** → **iOS → App** → Next
   - Product Name: `ScmViewer` (tuỳ ý)
   - Interface: **SwiftUI**, Language: **Swift**
2. Kéo `ScmRealityKitDebugView.swift` vào project navigator, tick ✅ **Add to target**
3. Thay nội dung file `ScmViewerApp.swift` (file có `@main`) bằng file `ScmViewerApp.swift` trong zip này
   (hoặc chỉ cần đổi `ContentView()` → `ScmRealityKitDebugView()`)
4. Chọn simulator / device → ⌘R

## Cách dùng

- Kéo file `.scm` thả vào simulator (tự lưu vào Files app), hoặc AirDrop vào device
- Bấm **📂 Mở .scm** → chọn file
- Điều khiển: 1 ngón xoay, 2 ngón pan, pinch zoom, 🎯 reset camera
- Overlay dưới màn hình: FPS / draw calls (RealityKit statistics)

## Lưu ý

- Cần iOS 15.2+ (dùng ARView non-AR, không cần thiết bị có LiDAR/AR)
- File tự chứa: KHÔNG cần SCMReader.swift hay thư viện ngoài (không CocoaPods)
- Simulator render được nhưng chậm hơn device thật
