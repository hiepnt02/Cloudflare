//
//  ScmViewerApp.swift
//  ScmViewer
//
//  Entry point — thay nội dung file @main trong project mới bằng file này.
//

import SwiftUI

@main
struct ScmViewerApp: App {
    var body: some Scene {
        WindowGroup {
            ScmRealityKitDebugView()
        }
    }
}
