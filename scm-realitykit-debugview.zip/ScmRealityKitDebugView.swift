//
//  ScmRealityKitDebugView.swift
//  Quick3D
//
//  DEV-ONLY: render file .scm bằng RealityKit (ARView non-AR) — bản song song
//  với ScmNativeDebugView (SceneKit) để so trực tiếp cùng một file với web.
//
//  • 📂 chọn file .scm (kéo file vào simulator → Files → chọn)
//  • Camera orbit tự viết: 1 ngón xoay, 2 ngón pan, pinch zoom, 🎯 reset
//  • .showStatistics: overlay FPS / draw calls của RealityKit
//
//  Tự chứa: parse binary SCM ngay trong file này (cùng layout với SCMReader)
//  → không phụ thuộc ARProjectHepler / LayerNode, add vào target là chạy.
//
//  Cách mở nhanh — thay content tạm thời trong Quick3DApp.swift:
//      WindowGroup { ScmRealityKitDebugView() }
//

import SwiftUI
import RealityKit
import UniformTypeIdentifiers
import simd

// MARK: - SwiftUI View

struct ScmRealityKitDebugView: View {
    @State private var model: SCMRKModel?
    @State private var status = "Bấm 📂 để chọn file .scm"
    @State private var showPicker = false
    @State private var resetToken = 0

    var body: some View {
        ZStack(alignment: .top) {
            ScmRealityKitContainer(model: model, resetToken: resetToken)
                .ignoresSafeArea()

            HStack(spacing: 8) {
                Button("📂 Mở .scm") { showPicker = true }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color(red: 0.18, green: 0.44, blue: 0.70))
                    .foregroundColor(.white)
                    .cornerRadius(7)

                Button("🎯") { resetToken += 1 }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(Color.black.opacity(0.55))
                    .cornerRadius(7)

                Text(status)
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(.white)
                    .padding(6)
                    .background(Color.black.opacity(0.55))
                    .cornerRadius(6)

                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.top, 8)
        }
        .fileImporter(
            isPresented: $showPicker,
            allowedContentTypes: [UTType.data, UTType.item]
        ) { result in
            switch result {
            case .success(let url): loadScm(url)
            case .failure(let err): status = "Lỗi chọn file: \(err.localizedDescription)"
            }
        }
    }

    private func loadScm(_ url: URL) {
        guard url.pathExtension.lowercased() == "scm" else {
            status = "\(url.lastPathComponent) không phải .scm"
            return
        }
        status = "Đang parse \(url.lastPathComponent)…"
        // File từ Files app nằm ngoài sandbox — phải xin quyền security-scoped.
        let secured = url.startAccessingSecurityScopedResource()
        defer { if secured { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try Data(contentsOf: url)
            let t0 = CFAbsoluteTimeGetCurrent()
            let result = try SCMRealityKitParser.parse(data)
            let ms = Int((CFAbsoluteTimeGetCurrent() - t0) * 1000)
            model = SCMRKModel(root: result.root)
            status = "\(url.lastPathComponent) — \(result.entityCount) entity, "
                + "\(result.vertexCount) verts, \(result.triangleCount) tris — \(ms) ms"
        } catch {
            status = "❌ \(error.localizedDescription)"
        }
    }
}

// Bọc model trong class có id để UIViewRepresentable biết khi nào cần thay content.
final class SCMRKModel {
    let id = UUID()
    let root: Entity
    init(root: Entity) { self.root = root }
}

// MARK: - ARView container + orbit camera

struct ScmRealityKitContainer: UIViewRepresentable {
    let model: SCMRKModel?
    let resetToken: Int

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> ARView {
        let view = ARView(frame: .zero, cameraMode: .nonAR, automaticallyConfigureSession: false)
        view.environment.background = .color(UIColor(white: 0.12, alpha: 1))
        view.debugOptions = [.showStatistics]

        let c = context.coordinator
        c.arView = view

        view.scene.addAnchor(c.contentAnchor)

        // Camera
        c.camera.camera.fieldOfViewInDegrees = 60
        c.camera.camera.near = 0.05
        c.camera.camera.far = 20000
        c.cameraAnchor.addChild(c.camera)
        view.scene.addAnchor(c.cameraAnchor)
        c.updateCamera()

        // Bộ đèn mô phỏng viewer web (3 DirectionalLight + 1 đèn hắt từ dưới
        // thay cho AmbientLight — RealityKit không có ambient light).
        let lightAnchor = AnchorEntity(world: .zero)
        c.addDirectionalLight(to: lightAnchor, direction: SIMD3(-1, -2, -1.5), lux: 3000)
        c.addDirectionalLight(to: lightAnchor, direction: SIMD3(1, -1, 1), lux: 2000)
        c.addDirectionalLight(to: lightAnchor, direction: SIMD3(0.5, -1, -1), lux: 1600)
        c.addDirectionalLight(to: lightAnchor, direction: SIMD3(0, 1, 0.3), lux: 900)
        view.scene.addAnchor(lightAnchor)

        // Gestures: 1 ngón orbit, 2 ngón pan, pinch zoom
        let orbit = UIPanGestureRecognizer(target: c, action: #selector(Coordinator.handleOrbit(_:)))
        orbit.minimumNumberOfTouches = 1
        orbit.maximumNumberOfTouches = 1
        view.addGestureRecognizer(orbit)

        let truck = UIPanGestureRecognizer(target: c, action: #selector(Coordinator.handleTruck(_:)))
        truck.minimumNumberOfTouches = 2
        truck.maximumNumberOfTouches = 2
        view.addGestureRecognizer(truck)

        let pinch = UIPinchGestureRecognizer(target: c, action: #selector(Coordinator.handlePinch(_:)))
        view.addGestureRecognizer(pinch)

        return view
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        let c = context.coordinator
        if let model = model, model.id != c.loadedID {
            c.loadedID = model.id
            c.contentAnchor.children.removeAll()
            c.contentAnchor.addChild(model.root)
            c.frameCamera()
        }
        if resetToken != c.appliedResetToken {
            c.appliedResetToken = resetToken
            c.frameCamera()
        }
    }

    final class Coordinator {
        weak var arView: ARView?
        var loadedID: UUID?
        var appliedResetToken = 0

        let contentAnchor = AnchorEntity(world: .zero)
        let cameraAnchor = AnchorEntity(world: .zero)
        let camera = PerspectiveCamera()

        // Orbit state
        var target: SIMD3<Float> = .zero
        var distance: Float = 10
        var azimuth: Float = .pi / 4
        var elevation: Float = .pi / 5

        func addDirectionalLight(to anchor: AnchorEntity, direction: SIMD3<Float>, lux: Float) {
            let light = DirectionalLight()
            light.light.intensity = lux
            // DirectionalLight chiếu theo trục -Z của entity → hướng -Z vào `direction`
            light.look(at: normalize(direction), from: .zero, relativeTo: nil)
            anchor.addChild(light)
        }

        func updateCamera() {
            elevation = max(-1.55, min(1.55, elevation))
            distance = max(0.05, min(15000, distance))
            let ce = cos(elevation)
            let offset = SIMD3<Float>(
                distance * ce * sin(azimuth),
                distance * sin(elevation),
                distance * ce * cos(azimuth)
            )
            camera.look(at: target, from: target + offset, relativeTo: nil)
        }

        // Đặt camera nhìn trọn bounding sphere của model
        func frameCamera() {
            let bounds = contentAnchor.visualBounds(relativeTo: nil)
            let radius = bounds.boundingRadius
            if radius.isFinite && radius > 0 {
                target = bounds.center
                distance = radius * 2.2
            } else {
                target = .zero
                distance = 10
            }
            azimuth = .pi / 4
            elevation = .pi / 5
            updateCamera()
        }

        @objc func handleOrbit(_ g: UIPanGestureRecognizer) {
            let t = g.translation(in: g.view)
            g.setTranslation(.zero, in: g.view)
            azimuth -= Float(t.x) * 0.008
            elevation += Float(t.y) * 0.008
            updateCamera()
        }

        @objc func handleTruck(_ g: UIPanGestureRecognizer) {
            let t = g.translation(in: g.view)
            g.setTranslation(.zero, in: g.view)
            let m = camera.transform.matrix
            let right = SIMD3<Float>(m.columns.0.x, m.columns.0.y, m.columns.0.z)
            let up = SIMD3<Float>(m.columns.1.x, m.columns.1.y, m.columns.1.z)
            let k = distance * 0.0015
            target -= right * Float(t.x) * k
            target += up * Float(t.y) * k
            updateCamera()
        }

        @objc func handlePinch(_ g: UIPinchGestureRecognizer) {
            guard g.state == .changed else { return }
            distance /= Float(g.scale)
            g.scale = 1
            updateCamera()
        }
    }
}

// MARK: - SCM → RealityKit parser (cùng binary layout với SCMReader.swift)

enum SCMRealityKitParser {

    struct Result {
        let root: Entity
        let entityCount: Int
        let vertexCount: Int
        let triangleCount: Int
    }

    private static let headerSize = 32

    private enum BlockType: UInt16 {
        case parent = 0x0001, meshId = 0x0002, materialId = 0x0003, color = 0x0004
        case position = 0x0005, rotation = 0x0006, scale = 0x0007
        case name = 0x000A
        case geometryTable = 0x0100, materialTable = 0x0101
        case positionsStream = 0x0200, indicesStream = 0x0203
        case stringTable = 0x0206
    }

    private struct BlockEntry {
        let blockType: UInt16
        let offset: UInt32
        let rawSize: UInt32
    }

    private struct Geometry {
        let vertexCount: UInt32
        let indexCount: UInt32
        let vertexOffset: UInt32
        let indexOffset: UInt32
    }

    private struct Material {
        let opacity: UInt8
    }

    static func parse(_ data: Data) throws -> Result {
        let reader = RKBinaryReader(data)

        // Magic "SCM\0" hoặc "SCMZ"
        let m0 = reader.readUInt8(), m1 = reader.readUInt8(), m2 = reader.readUInt8(), m3 = reader.readUInt8()
        guard m0 == 0x53, m1 == 0x43, m2 == 0x4D, (m3 == 0x00 || m3 == 0x5A) else {
            throw NSError(domain: "SCMRealityKitParser", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Invalid SCM magic"])
        }

        _ = reader.readUInt16() // version
        let entityCount = Int(reader.readUInt32())
        let blockCount = Int(reader.readUInt16())
        let geometryCount = Int(reader.readUInt32())
        let materialCount = Int(reader.readUInt32())
        _ = reader.readUInt32() // textureCount
        let coordSystem = reader.readUInt8() // 0=Y-up, 1=Z-up
        reader.seek(headerSize)

        // Block directory (18 byte/entry — đọc đủ field như SCMReader)
        var blocks: [BlockEntry] = []
        for _ in 0..<blockCount {
            let blockType = reader.readUInt16()
            _ = reader.readUInt8() // dataType
            _ = reader.readUInt8() // encoding
            _ = reader.readUInt8() // compression
            _ = reader.readUInt8() // elementSize
            let offset = reader.readUInt32()
            _ = reader.readUInt32() // compressedSize
            let rawSize = reader.readUInt32()
            blocks.append(BlockEntry(blockType: blockType, offset: offset, rawSize: rawSize))
        }

        let N = entityCount
        func findBlock(_ type: BlockType) -> BlockEntry? {
            blocks.first { $0.blockType == type.rawValue }
        }

        func readMaskedInt32(_ type: BlockType, defaultVal: Int32) -> [Int32] {
            guard let block = findBlock(type) else { return [Int32](repeating: defaultVal, count: N) }
            let r = RKBinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            var result = [Int32](repeating: defaultVal, count: N)
            for i in 0..<N where mask[i] != 0 { result[i] = r.readInt32() }
            return result
        }

        func readMaskedFloat3(_ type: BlockType, defaultVal: SIMD3<Float>) -> [SIMD3<Float>] {
            guard let block = findBlock(type) else { return [SIMD3<Float>](repeating: defaultVal, count: N) }
            let r = RKBinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            var result = [SIMD3<Float>](repeating: defaultVal, count: N)
            for i in 0..<N where mask[i] != 0 {
                result[i] = SIMD3(r.readFloat32(), r.readFloat32(), r.readFloat32())
            }
            return result
        }

        func readMaskedFloat4(_ type: BlockType, defaultVal: SIMD4<Float>) -> [SIMD4<Float>] {
            guard let block = findBlock(type) else { return [SIMD4<Float>](repeating: defaultVal, count: N) }
            let r = RKBinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            var result = [SIMD4<Float>](repeating: defaultVal, count: N)
            for i in 0..<N where mask[i] != 0 {
                result[i] = SIMD4(r.readFloat32(), r.readFloat32(), r.readFloat32(), r.readFloat32())
            }
            return result
        }

        func readMaskedUInt32(_ type: BlockType, defaultVal: UInt32) -> [UInt32] {
            guard let block = findBlock(type) else { return [UInt32](repeating: defaultVal, count: N) }
            let r = RKBinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            var result = [UInt32](repeating: defaultVal, count: N)
            for i in 0..<N where mask[i] != 0 { result[i] = r.readUInt32() }
            return result
        }

        let parentIds = readMaskedInt32(.parent, defaultVal: -1)
        let meshIds = readMaskedInt32(.meshId, defaultVal: -1)
        let materialIds = readMaskedInt32(.materialId, defaultVal: -1)
        let positions = readMaskedFloat3(.position, defaultVal: .zero)
        let rotations = readMaskedFloat4(.rotation, defaultVal: SIMD4(0, 0, 0, 1))
        let scales = readMaskedFloat3(.scale, defaultVal: SIMD3(1, 1, 1))
        let nameRefs = readMaskedUInt32(.name, defaultVal: 0)

        // String table
        var strings: [String] = [""]
        if let block = findBlock(.stringTable) {
            let r = RKBinaryReader(data)
            r.seek(Int(block.offset))
            let tableData = r.readBytes(Int(block.rawSize))
            var current = ""
            for byte in tableData {
                if byte == 0 {
                    strings.append(current)
                    current = ""
                } else {
                    current.append(Character(UnicodeScalar(byte)))
                }
            }
            if !current.isEmpty { strings.append(current) }
        }

        // Geometry table (52 byte/entry)
        var geometries: [Geometry] = []
        if let block = findBlock(.geometryTable) {
            let r = RKBinaryReader(data)
            r.seek(Int(block.offset))
            for _ in 0..<geometryCount {
                let vertexCount = r.readUInt32()
                let indexCount = r.readUInt32()
                let vertexOffset = r.readUInt32()
                _ = r.readInt32() // normalOffset
                _ = r.readInt32() // uvOffset
                let indexOffset = r.readUInt32()
                _ = r.readInt32() // vertexColorOffset
                _ = r.readBytes(24) // bboxMin + bboxMax
                geometries.append(Geometry(
                    vertexCount: vertexCount, indexCount: indexCount,
                    vertexOffset: vertexOffset, indexOffset: indexOffset
                ))
            }
        }

        // Material table (16 byte/entry)
        var materials: [Material] = []
        if let block = findBlock(.materialTable) {
            let r = RKBinaryReader(data)
            r.seek(Int(block.offset))
            for _ in 0..<materialCount {
                _ = r.readInt32() // textureId
                _ = r.readUInt16() // textureScaleU
                _ = r.readUInt16() // textureScaleV
                let opacity = r.readUInt8()
                _ = r.readUInt8() // flags
                _ = r.readBytes(6) // reserved
                materials.append(Material(opacity: opacity))
            }
        }

        // Entity color (mask + RGBA uint8x4)
        var entityColors = [SIMD4<UInt8>](repeating: SIMD4(0, 0, 0, 0), count: N)
        if let block = findBlock(.color) {
            let r = RKBinaryReader(data)
            r.seek(Int(block.offset))
            let mask = (0..<N).map { _ in r.readUInt8() }
            for i in 0..<N where mask[i] != 0 {
                entityColors[i] = SIMD4(r.readUInt8(), r.readUInt8(), r.readUInt8(), r.readUInt8())
            }
        }

        let posBlock = findBlock(.positionsStream)
        let indexBlock = findBlock(.indicesStream)

        // Mesh cache: geometry dùng chung giữa nhiều entity chỉ generate 1 lần
        var meshCache: [Int: MeshResource] = [:]
        var totalVertices = 0
        var totalTriangles = 0

        func meshFor(_ meshId: Int) -> MeshResource? {
            if let cached = meshCache[meshId] { return cached }
            guard meshId >= 0 && meshId < geometries.count,
                  let posBlock = posBlock, let indexBlock = indexBlock else { return nil }
            let geom = geometries[meshId]
            guard geom.vertexCount > 0 && geom.indexCount > 0 else { return nil }

            let vCount = Int(geom.vertexCount)
            let iCount = Int(geom.indexCount)

            var vertices = [SIMD3<Float>]()
            vertices.reserveCapacity(vCount)
            let posReader = RKBinaryReader(data)
            posReader.seek(Int(posBlock.offset) + Int(geom.vertexOffset))
            for _ in 0..<vCount {
                vertices.append(SIMD3(posReader.readFloat32(), posReader.readFloat32(), posReader.readFloat32()))
            }

            var indices = [UInt32]()
            indices.reserveCapacity(iCount)
            let idxReader = RKBinaryReader(data)
            idxReader.seek(Int(indexBlock.offset) + Int(geom.indexOffset))
            for _ in 0..<iCount {
                indices.append(idxReader.readUInt32())
            }

            var descriptor = MeshDescriptor(name: "scm_geom_\(meshId)")
            descriptor.positions = MeshBuffers.Positions(vertices)
            descriptor.primitives = .triangles(indices)
            // Không set normals — RealityKit tự sinh (octahedral normals của SCM còn cần debug)

            guard let mesh = try? MeshResource.generate(from: [descriptor]) else { return nil }
            meshCache[meshId] = mesh
            totalVertices += vCount
            totalTriangles += iCount / 3
            return mesh
        }

        // Build entity cho từng SCM entity
        let rootNode = Entity()
        rootNode.name = "SCM_Root"
        var nodes = [Entity?](repeating: nil, count: N)

        for i in 0..<N {
            let entity: Entity
            let meshId = Int(meshIds[i])

            if let mesh = meshFor(meshId) {
                var mat = PhysicallyBasedMaterial()
                mat.roughness = 0.6
                mat.metallic = 0.0
                mat.baseColor = .init(tint: UIColor(white: 0.8, alpha: 1.0))

                var opacity: Float = 1.0
                let matId = Int(materialIds[i])
                if matId >= 0 && matId < materials.count && materials[matId].opacity < 255 {
                    opacity = Float(materials[matId].opacity) / 255.0
                }

                let c = entityColors[i]
                if c.w > 0 {
                    mat.baseColor = .init(tint: UIColor(
                        red: CGFloat(c.x) / 255.0,
                        green: CGFloat(c.y) / 255.0,
                        blue: CGFloat(c.z) / 255.0,
                        alpha: 1.0
                    ))
                    opacity = Swift.min(opacity, Float(c.w) / 255.0)
                }

                if opacity < 1.0 {
                    mat.blending = .transparent(opacity: .init(floatLiteral: opacity))
                }

                entity = ModelEntity(mesh: mesh, materials: [mat])
            } else {
                entity = Entity()
            }

            let nameIdx = Int(nameRefs[i])
            entity.name = nameIdx < strings.count ? strings[nameIdx] : "Entity_\(i)"

            let q = rotations[i]
            entity.transform = Transform(
                scale: scales[i],
                rotation: simd_quatf(ix: q.x, iy: q.y, iz: q.z, r: q.w),
                translation: positions[i]
            )

            nodes[i] = entity
        }

        // Hierarchy
        for i in 0..<N {
            guard let entity = nodes[i] else { continue }
            let parentId = Int(parentIds[i])
            if parentId >= 0 && parentId < N, let parent = nodes[parentId] {
                parent.addChild(entity)
            } else {
                rootNode.addChild(entity)
            }
        }

        // Z-up → cùng ma trận chuyển hệ trục với SCMReader (SceneKit) để 2 bản native khớp nhau
        if coordSystem == 1 {
            rootNode.transform = Transform(matrix: simd_float4x4(
                SIMD4<Float>(1, 0, 0, 0),
                SIMD4<Float>(0, 0, 1, 0),
                SIMD4<Float>(0, -1, 0, 0),
                SIMD4<Float>(0, 0, 0, 1)
            ))
        }

        return Result(
            root: rootNode,
            entityCount: N,
            vertexCount: totalVertices,
            triangleCount: totalTriangles
        )
    }
}

// MARK: - Binary reader (bản copy local — BinaryReader trong SCMReader.swift là private)

private final class RKBinaryReader {
    let data: Data
    var pos: Int = 0

    init(_ data: Data) { self.data = data }

    func seek(_ offset: Int) { pos = offset }

    func readUInt8() -> UInt8 {
        let v = data[data.startIndex + pos]
        pos += 1
        return v
    }

    func readUInt16() -> UInt16 {
        let v = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + 2))
            .withUnsafeBytes { $0.load(as: UInt16.self) }
        pos += 2
        return v
    }

    func readUInt32() -> UInt32 {
        let v = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + 4))
            .withUnsafeBytes { $0.load(as: UInt32.self) }
        pos += 4
        return v
    }

    func readInt32() -> Int32 {
        let v = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + 4))
            .withUnsafeBytes { $0.load(as: Int32.self) }
        pos += 4
        return v
    }

    func readFloat32() -> Float {
        let v = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + 4))
            .withUnsafeBytes { $0.load(as: Float.self) }
        pos += 4
        return v
    }

    func readBytes(_ count: Int) -> Data {
        let sub = data.subdata(in: (data.startIndex + pos)..<(data.startIndex + pos + count))
        pos += count
        return sub
    }
}
